# Title Capitalizer - Installation

Title Capitalizer is an Office Add-in for Word, Excel, and PowerPoint.
It applies title case to your selected text using popular style guides
(AP, APA, Chicago, MLA, NY Times, Wikipedia, Bluebook, AMA).

A single `manifest.xml` file works on every platform - what changes is
how you load it. Follow the section below that matches the platform you
are installing on.


## Installing on Mac (Word, Excel, PowerPoint)

Microsoft 365 on Mac sideloads add-ins from a per-app `wef` folder.

1. Quit Word, Excel, and PowerPoint.
2. Open Finder. Press **Cmd+Shift+G** and paste the path for the host
   you want, creating the folder if it doesn't exist:
   - Word:        `~/Library/Containers/com.microsoft.Word/Data/Documents/wef`
   - Excel:       `~/Library/Containers/com.microsoft.Excel/Data/Documents/wef`
   - PowerPoint:  `~/Library/Containers/com.microsoft.Powerpoint/Data/Documents/wef`
3. Copy `manifest.xml` from this archive into that folder. (Copy it
   into all three for full coverage.)
4. Launch the Office app. Open the **Insert** tab, choose **Add-ins**
   (or **My Add-ins**) and switch to the **Developer Add-ins** group.
   Select *Title Capitalizer*.
5. The **Title Capitalizer** group appears on the **Home** tab.

Microsoft documentation:
https://learn.microsoft.com/office/dev/add-ins/testing/sideload-an-office-add-in-on-mac
