# Title Capitalizer - Installation

Title Capitalizer is an Office Add-in for Word, Excel, and PowerPoint.
It applies title case to your selected text using popular style guides
(AP, APA, Chicago, MLA, NY Times, Wikipedia, Bluebook, AMA).

A single `manifest.xml` file works on every platform - what changes is
how you load it. Follow the section below that matches the platform you
are installing on.


## Installing on Windows (Word, Excel, PowerPoint)

Microsoft 365 on Windows supports sideloading add-ins from a shared
folder. You can use a local folder for personal use.

1. Pick a folder, for example `C:\OfficeAddins\TitleCapitalizer\`.
2. Copy `manifest.xml` from this archive into that folder.
3. In Windows Explorer, right-click the folder, choose **Properties >
   Sharing > Share...**, and share it with yourself. Note the network
   path Windows assigns (it looks like `\\PCNAME\OfficeAddins\TitleCapitalizer`).
4. Open Word (or Excel/PowerPoint). Go to **File > Options > Trust
   Center > Trust Center Settings > Trusted Add-in Catalogs**.
5. Paste the share path into **Catalog URL**, check **Show in Menu**,
   click **Add catalog**, then **OK**. Restart the Office app.
6. Open the **Insert** tab and choose **My Add-ins > Shared Folder**.
   You should see *Title Capitalizer*. Click **Add**.
7. A new **Title Capitalizer** group appears on the **Home** tab. Click
   **Title Capitalizer** to open the task pane, or use **Quick Style**
   to apply a specific style guide to your selection.

Microsoft documentation:
https://learn.microsoft.com/office/dev/add-ins/testing/create-a-network-shared-folder-catalog-for-task-pane-and-content-add-ins
