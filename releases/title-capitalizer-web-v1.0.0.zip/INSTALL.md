# Title Capitalizer - Installation

Title Capitalizer is an Office Add-in for Word, Excel, and PowerPoint.
It applies title case to your selected text using popular style guides
(AP, APA, Chicago, MLA, NY Times, Wikipedia, Bluebook, AMA).

A single `manifest.xml` file works on every platform - what changes is
how you load it. Follow the section below that matches the platform you
are installing on.


## Installing on Office for the Web (Word, Excel, PowerPoint Online)

The web versions of Office accept a manifest upload directly.

1. Sign in to https://www.office.com and open Word, Excel, or
   PowerPoint for the web.
2. Open or create a document.
3. On the **Home** tab choose **Add-ins** (or **Insert > Add-ins** in
   some tenants). In the dialog, click **More Add-ins**.
4. Switch to the **My Add-ins** tab, choose **Manage My Add-ins** in
   the upper-right, and select **Upload My Add-in**.
5. Browse to the `manifest.xml` from this archive and click **Upload**.
6. A new **Title Capitalizer** group appears on the **Home** tab.

Microsoft documentation:
https://learn.microsoft.com/office/dev/add-ins/testing/sideload-office-add-ins-for-testing
